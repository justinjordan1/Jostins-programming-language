/* package src.Recognizer;

import src.lexicalAnalysis.Lexeme;
import src.lexicalAnalysis.Lexer;
import src.lexicalAnalysis.Types;


import java.util.ArrayList;


public class Recognizer {

    private Lexer lexer;
    private ArrayList<Lexeme> lexemes;
    private int currentPosition;

    public Recognizer(String input) {
        this.lexer = new Lexer(input);
        this.lexemes = lexer.lex();
        this.currentPosition = 0;
    }

    public boolean isAtEnd() {
        return currentPosition >= lexemes.size();
    }

    public Lexeme peek() {
        if (currentPosition >= lexemes.size()) {
            return null;
        }
        return lexemes.get(currentPosition);
    }

    public Lexeme advance() {
        if (currentPosition >= lexemes.size()) {
            return null;
        }
        Lexeme current = lexemes.get(currentPosition);
        currentPosition++;
        return current;
    }

    public void consume(Types type) {
        if (peek().getType() == type) {
            advance();
        }
        //TODO error stuff
    }

    public boolean match(Types type) {
        if (peek().getType() == type) {
            advance();
            return true;
        } else {
            return false;
        }
    }

    public void recognize() {
        program();
        if (!isAtEnd()) {
            throw new RuntimeException("Unexpected token found: " + peek().getType());
        }
    }

    private void program() {
        statementList();
    }

    private void statementList() {
        while (!isAtEnd()) {
            statement();
        }
    }

    private void statement() {
        if (match(Types.VAR)) {
            varActivities();
            consume(Types.SEMICOLON, "Expected ';' after variable activity.");
        } else if (match(Types.IF)) {
            conditional();
            consume(Types.SEMICOLON, "Expected ';' after conditional statement.");
        } else if (match(Types.IDENTIFIER) && peek().getType() == Types.COLON) {
            functionDefinition();
            consume(Types.SEMICOLON, "Expected ';' after function definition.");
        } else if (match(Types.FOR) || match(Types.FOREACH)) {
            loop();
            consume(Types.SEMICOLON, "Expected ';' after loop statement.");
        } else if (match(Types.LEFT_BRACE)) {
            block();
        } else if (match(Types.RETURN)) {
            returnStatement();
            consume(Types.SEMICOLON, "Expected ';' after return statement.");
        } else if (match(Types.BREAK)) {
            consume(Types.SEMICOLON, "Expected ';' after 'break' statement.");
        } else if (match(Types.IDENTIFIER)) {
            collectionActivities();
            consume(Types.SEMICOLON, "Expected ';' after collection activity.");
        } else {
            throw new RuntimeException("Unexpected token found: " + peek().getType());
        }
    }

    private void varActivities() {
        if (match(Types.VAR)) {
            varInitialization();
        } else if (match(Types.IDENTIFIER)) {
            if (match(Types.ASSIGN)) {
                expression();
            } else if (match(Types.COLON)) {
                consume(Types.IDENTIFIER, "Expected type identifier after ':'");
                consume(Types.ASSIGN, "Expected '=' after type identifier.");
                expression();
            } else if (match(Types.INCREMENT) || match(Types.DECREMENT)) {
                // unaryVarAssignment
            } else {
                throw new RuntimeException("Unexpected token found: " + peek().getType());
            }
        } else {
            throw new RuntimeException("Unexpected token found: " + peek().getType());
        }
    }

    private void varInitialization() {
        consume(Types.IDENTIFIER, "Expected variable identifier after 'var' keyword.");
        varIdentifierList();
        consume(Types.IDENTIFIER, "Expected type identifier after variable identifiers.");
        consume(Types.ASSIGNMENT, "Expected '=' after type identifier.");
        expression();
    }

    private void varIdentifierList() {
        while (match(Types.COMMA)) {
            consume(Types.IDENTIFIER, "Expected variable identifier after ','");
        }
    }
}

 */