package src.Evaluation;

public class LoopControlException {
}
